public class InvalidShift extends Exception
{
	public InvalidShift()
	{
		super("ERROR: Invalid pay rate.");
	}
}