public class InvalidPayRate extends Exception
{
	public InvalidPayRate()
	{
		super("ERROR: Invalid pay rate.");
	}
}