//make one of these for PayRate and Shift as well

public class InvalidEmployeeNumber extends Exception
{
	public InvalidEmployeeNumber()
	{
		super("ERROR: Invalid employee number.");
	}
}