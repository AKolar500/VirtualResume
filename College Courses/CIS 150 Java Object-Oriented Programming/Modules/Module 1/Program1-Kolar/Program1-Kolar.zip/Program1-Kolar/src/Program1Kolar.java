/*Programmer: Alex Kolar
 *Date: 1/18/2013
 *Assignment: Hello World
 *Class: CIS150AB 28591
 */

// While not my first Java program ever written, it's my first assignment in this class.
public class Program1Kolar {

    public static void main(String[] args) {

    	// TODO, add your application code
    	System.out.println("Hello Mo-Fo's!");
    }
}
