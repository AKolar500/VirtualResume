﻿Module Module1

    Public decTotalCost As Decimal

End Module
