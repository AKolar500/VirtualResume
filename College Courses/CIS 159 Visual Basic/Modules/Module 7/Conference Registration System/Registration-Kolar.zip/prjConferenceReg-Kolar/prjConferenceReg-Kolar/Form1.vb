﻿Public Class frmMain

    Private Sub btnOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOptions.Click
        'Declare vars
        Dim frmOptions As Form2

        frmOptions.Show()
    End Sub
End Class
