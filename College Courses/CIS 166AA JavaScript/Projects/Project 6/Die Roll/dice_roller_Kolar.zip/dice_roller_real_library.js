var Die = function(sides) {
	this.value = 
}