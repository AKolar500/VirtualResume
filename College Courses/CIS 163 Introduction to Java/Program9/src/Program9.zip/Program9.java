/*Alex Kolar
 *11/2/2011
 *Mr. R. Grover
 *Cis163
 *26279
 *
 *Combines all other files. This is the file that is to be run.
 */
import javax.swing.JFrame;
public class Program9 {

    public static void main(String[] args) {
    	JFrame frame = new FlowFlow();
    	JFrame frame2 = new BorderFlow();
    	JFrame frame3 = new BorderGrid();
        }
}
