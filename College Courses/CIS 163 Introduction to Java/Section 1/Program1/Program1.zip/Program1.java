//CIS 163AA
//Section 46494
//Alex Kolar
//Mr. R. B. Grover
//1-25-2011

/* How this works on my computer:
In the book's words, "line 1 defines a class." I think that a class is some type of category that holds executables
(or something like that) that will be run once that category is used/activated. I think that line 2 either defines or
creates a location where the command is run. I am sure that line 4 is the executable itself. */

public class Program1{
	public static void main(String[] args){
	//This is a comment. Are you scared yet?
	System.out.println("Alex Kolar wuz here...or wuz he?");
	}
}